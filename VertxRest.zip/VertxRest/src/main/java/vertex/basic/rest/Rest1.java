package vertex.basic.rest;

import java.net.http.HttpRequest;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.http.HttpServer;
import io.vertx.core.http.HttpServerRequest;
import io.vertx.core.http.HttpServerResponse;
import io.vertx.ext.web.Router;
import io.vertx.rxjava.ext.web.Route;

public class Rest1 extends AbstractVerticle {
	
	public static void main(String[] args) {
		Vertx vertx = Vertx.vertx();
		//vertx.deployVerticle(new Rest1().getClass().getName());
		vertx.deployVerticle(new RestServiceVerticle().getClass().getName());
		
		
	}
	 public void start(Future<Void> future) {

	    	HttpServer server = vertx.createHttpServer();

	    	Router router = Router.router(vertx);
	    	//io.vertx.ext.web.Route myRoute = router.route("/myendpoint");
	    	io.vertx.ext.web.Route myRoute= router.route();
	    	myRoute.handler(ctx -> {

	    	  // This handler will be called for every request
	    	  HttpServerResponse response = ctx.response();
	    	  response.putHeader("content-type", "text/plain");
	    	 // response.putHeader("content-length", "20");
              // response.write("route3");
	    	  // Write to the response and end it
	    	  response.end("Hello World from Vert.x-Web!");
	    	});
	    	
	    	server.requestHandler(router::accept).listen(8081);
	    	
	    }
}