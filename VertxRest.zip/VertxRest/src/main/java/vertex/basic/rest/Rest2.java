package vertex.basic.rest;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.Vertx;
import io.vertx.core.http.HttpServer;
import io.vertx.core.http.HttpServerResponse;
import io.vertx.ext.web.Route;
import io.vertx.ext.web.Router;

public class Rest2 extends AbstractVerticle{
	
	public static void main(String[] args) {
		Vertx vertx = Vertx.vertx();
		vertx.deployVerticle(new Rest2().getClass().getName());
		
		
		
	}
	
	public void start(Future<Void> future) {

Vertx vertx = Vertx.vertx();
		
		HttpServer server = vertx.createHttpServer();

    	Router router = Router.router(vertx);
    	//io.vertx.ext.web.Route myRoute = router.route("/myendpoint");
    	Route handler1 =  router.get("/hello").handler(routingContext -> {
    		System.out.println("came to hello");
    		HttpServerResponse response = routingContext.response();
    		
    		response.setChunked(true);
    		response.write("fhf get");
    		response.end();
    	});
    	
    	
    	Route handler2 =  router.post("/hello").handler(routingContext -> {
    		System.out.println("came to hello");
    		HttpServerResponse response = routingContext.response();
    		
    		response.setChunked(true);
    		response.write("fhf post");
    		response.end();
    	});
    	
    	
    	server.requestHandler(router::accept).listen(8080);
    	
		
		
	}
	
		
	
	
	

}
