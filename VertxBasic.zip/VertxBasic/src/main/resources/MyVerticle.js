// myVerticle.js
const { Verticle } = require('@vertx/core');

class MyVerticle extends Verticle {
  start() {
    console.log('JavaScript Verticle started.');
  }

  stop() {
    console.log('JavaScript Verticle stopped.');
  }
}

module.exports = MyVerticle;
