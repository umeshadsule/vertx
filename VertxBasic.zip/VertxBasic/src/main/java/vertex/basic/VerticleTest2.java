package vertex.basic;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.Vertx;

public class VerticleTest2 extends AbstractVerticle{
	
	       
	 @Override
	    public void start(Future<Void> future) {
		 
		 future.complete();
        
	        System.out.println(" VerticleTest2 start method called");
	           
	        
	    }
	 
	 @Override
	    public void stop(Future<Void> future) {
	        System.out.println(" VerticleTest2 stop method called");
	        
	    }
}
