package vertex.basic;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Vertx;

public class EventBusTest extends AbstractVerticle {
	static Vertx vertx = Vertx.vertx();
	
	public static void main(String[] args) {
 		

 		vertx.deployVerticle(EventBusTest.class.getName());
}
	
	
	@Override
	public void start() throws Exception {
		// TODO Auto-generated method stub
		

		//Register a consumer on the event bus to receive messages
		vertx.eventBus().consumer("example.address", message -> {
		 System.out.println("Received message: " + message.body());
		});
		
		vertx.eventBus().consumer("example.address", message -> {
			 System.out.println("Received message: " + message.body());
		});
		
		
		//Send a message on the event bus
		//vertx.eventBus().send("example.address", "Hello, world!");
		
		
		//Publish
		vertx.eventBus().publish("example.address", "Hello, world!");
	}
	
}
