package vertex.basic;

import io.netty.util.concurrent.Promise;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.Vertx;
import io.vertx.core.http.HttpServer;

public class HttpServerBasic extends AbstractVerticle {

	
	
	public static void main(String[] args) {
 		Vertx vertx = Vertx.vertx();

 		vertx.deployVerticle(HttpServerBasic.class.getName());
}

	 private HttpServer server;
     
	 public void start(Future future) {
		 
		 vertx.setPeriodic(10000, id -> {
			   // This handler will get called every second
			
			   System.out.println("timer fired!");
			 });
		 
		  server = vertx.createHttpServer().requestHandler(req -> {
		   //int a= 1/0;
		  
	     req.response()
	       .putHeader("content-type", "text/plain")
	       .end("Hello from Vert.x!");
	     });

	   // Now bind the server:
	   server.listen(8080, res -> {
		   System.out.println("1");
	     if (res.succeeded()) {
	    	 System.out.println("2");
	      // future.complete();
	     } else {
	    	 System.out.println("3");
	       future.fail(res.cause());
	     }
	   });
	 }
	}