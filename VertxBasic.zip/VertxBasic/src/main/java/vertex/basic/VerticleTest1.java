package vertex.basic;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.Vertx;

public class VerticleTest1 extends AbstractVerticle {
	
	
//	public static void main(String[] args) {
// 		Vertx vertx = Vertx.vertx();
//
// 		vertx.deployVerticle(VertexTest1.class.getName());
//   }

	  @Override
	  public void start() {
	   
    	  System.out.println("start called");

	  }
	  

    
    @Override
    public void stop() {
        System.out.println("stop called");
        
    }

	  
	}