package vertex.basic;




import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.Vertx;

public class VerticleTest extends AbstractVerticle {
   
	 	
	static String path = " C:\\ProjectData\\MyVerticle.js";
    public static void main(String[] args) {
        Vertx vertx = Vertx.vertx();
  
        String jsVerticlePath = VerticleTest.class.getResource("/MyVerticle.js").getFile();       

        vertx.deployVerticle(VerticleTest1.class.getName(), result -> {
        	
        	
        	System.out.println(result.succeeded());
            if (result.succeeded()) {
                String deploymentID = result.result();
                System.out.println("VertexTest1 deployed successfully. Deployment ID: " + deploymentID);
                vertx.undeploy(deploymentID);

            } else {
                System.err.println("Failed to deploy verticle: " + result.cause());
            }
        });
//        
        // Run Other js verticles inside java
        vertx.deployVerticle("js:"+path, result -> {
            if (result.succeeded()) {
                System.out.println("JavaScript Verticle deployed successfully.");
            } else {
                System.err.println("Failed to deploy JavaScript Verticle: " + result.cause());
            }
        });
        
        
        vertx.deployVerticle(VerticleTest2.class.getName(), result -> {
        	System.out.println(result.succeeded());
            if (result.succeeded()) {
                String deploymentID = result.result();
                System.out.println("VerticleTest2 deployed successfully. Deployment ID: " + deploymentID);
                //vertx.undeploy(deploymentID);

            } else {
                System.err.println("Failed to deploy verticle: " + result.cause());
            }
        });
      
        
   
       
    }

  
}

