package vertex.basic;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.Vertx;

public class FutureTest extends AbstractVerticle {
	
	
//	public static void main(String[] args) {
// 		Vertx vertx = Vertx.vertx();
//
// 		vertx.deployVerticle(FutureTest1.class.getName());
//   }

	  @Override
	  public void start() {
	    // Perform an asynchronous operation
	    Future<String> future = Future.future();
	   vertx.setTimer(1000, id -> future.complete("Hello World.!"));

	    // Return the result of the asynchronous operation
	    future.setHandler(ar -> {
	    	  System.out.println("1");
	      if (ar.succeeded()) {
	    	  System.out.println("2");
	        System.out.println(ar.result());
	       
	      } else {
	    	  System.out.println("3");
	       
	      }
	    });
	  }
	}