package vertex.basic;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.Vertx;

public class ExecuteBlockTest extends AbstractVerticle{
	
	 	public static void main(String[] args) {
	 		Vertx vertx = Vertx.vertx();

	 		vertx.deployVerticle(ExecuteBlockTest.class.getName() );
	}
	
	
	 
	
	  public void start(Future<Void> startFuture) throws Exception {
		  
	    vertx.executeBlocking(future -> {
	      // Perform a blocking operation here
	      String result = blockingOperation();
	     future.complete(result);
	      
	    }, ar -> {
	    	
	      if (ar.succeeded()) {
	    	  
	        String result = (String) ar.result();
	        System.out.println("Blocking operation result: " + result);
	       startFuture.complete();
	        
	      } else {
	    	  
	        startFuture.fail(ar.cause());
	      }
	    });
	    
	  }
	  
	  private String blockingOperation() {
	    // Perform a blocking operation here
	    return "Hello, world!";
	  }

	}

